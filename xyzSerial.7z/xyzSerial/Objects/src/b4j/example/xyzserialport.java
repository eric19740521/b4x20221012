package b4j.example;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;

public class xyzserialport extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    public static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.xyzserialport", this);
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            ba.htSubs = htSubs;
             
        }
        if (BA.isShellModeRuntimeCheck(ba))
                this.getClass().getMethod("_class_globals", b4j.example.xyzserialport.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4j.object.JavaObject _serialport = null;
public b4j.example.main _main = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 4;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 6;BA.debugLine="Private SerialPort As JavaObject";
_serialport = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 7;BA.debugLine="End Sub";
return "";
}
public boolean  _closeport() throws Exception{
 //BA.debugLineNum = 60;BA.debugLine="public Sub closePort() As Boolean";
 //BA.debugLineNum = 62;BA.debugLine="Return SerialPort.RunMethod(\"closePort\",Null)";
if (true) return BA.ObjectToBoolean(_serialport.RunMethod("closePort",(Object[])(__c.Null)));
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return false;
}
public Object  _getcommports() throws Exception{
Object[] _availableports = null;
 //BA.debugLineNum = 15;BA.debugLine="public Sub GetCommPorts() As Object";
 //BA.debugLineNum = 17;BA.debugLine="Dim AvailablePorts() As Object = SerialPort.RunMe";
_availableports = (Object[])(_serialport.RunMethod("getCommPorts",(Object[])(__c.Null)));
 //BA.debugLineNum = 27;BA.debugLine="Return AvailablePorts";
if (true) return (Object)(_availableports);
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return null;
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 10;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 12;BA.debugLine="SerialPort.InitializeStatic(\"com.fazecast.jSerial";
_serialport.InitializeStatic("com.fazecast.jSerialComm.SerialPort");
 //BA.debugLineNum = 13;BA.debugLine="End Sub";
return "";
}
public boolean  _isopen() throws Exception{
 //BA.debugLineNum = 65;BA.debugLine="public Sub isOpen() As Boolean";
 //BA.debugLineNum = 67;BA.debugLine="Return SerialPort.RunMethod(\"isOpen\",Null)";
if (true) return BA.ObjectToBoolean(_serialport.RunMethod("isOpen",(Object[])(__c.Null)));
 //BA.debugLineNum = 68;BA.debugLine="End Sub";
return false;
}
public boolean  _openport() throws Exception{
 //BA.debugLineNum = 55;BA.debugLine="public Sub openPort() As Boolean";
 //BA.debugLineNum = 57;BA.debugLine="Return SerialPort.RunMethod(\"openPort\",Null)";
if (true) return BA.ObjectToBoolean(_serialport.RunMethod("openPort",(Object[])(__c.Null)));
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return false;
}
public String  _setcomport(String _comport) throws Exception{
Object[] _availableports = null;
int _i = 0;
anywheresoftware.b4j.object.JavaObject _port = null;
String _comportn = "";
 //BA.debugLineNum = 31;BA.debugLine="public Sub SetComPort(comPort As String)";
 //BA.debugLineNum = 32;BA.debugLine="Dim AvailablePorts() As Object = SerialPort.RunMe";
_availableports = (Object[])(_serialport.RunMethod("getCommPorts",(Object[])(__c.Null)));
 //BA.debugLineNum = 34;BA.debugLine="Dim i As Int = 0";
_i = (int) (0);
 //BA.debugLineNum = 35;BA.debugLine="For Each port As JavaObject In AvailablePorts";
_port = new anywheresoftware.b4j.object.JavaObject();
{
final Object[] group3 = _availableports;
final int groupLen3 = group3.length
;int index3 = 0;
;
for (; index3 < groupLen3;index3++){
_port = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(group3[index3]));
 //BA.debugLineNum = 36;BA.debugLine="Dim comPortN As String = port.RunMethod(\"getSyst";
_comportn = BA.ObjectToString(_port.RunMethod("getSystemPortName",(Object[])(__c.Null)));
 //BA.debugLineNum = 38;BA.debugLine="If comPortN = comPort Then";
if ((_comportn).equals(_comport)) { 
 //BA.debugLineNum = 39;BA.debugLine="SerialPort = AvailablePorts(i)";
_serialport = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_availableports[_i]));
 };
 //BA.debugLineNum = 41;BA.debugLine="i=i+1";
_i = (int) (_i+1);
 }
};
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return "";
}
public String  _setcomportparameters(int _baudrate,int _databits,int _stopbits,int _parity) throws Exception{
 //BA.debugLineNum = 49;BA.debugLine="public Sub SetComPortParameters(BaudRate As Int,Da";
 //BA.debugLineNum = 51;BA.debugLine="SerialPort.RunMethod(\"setComPortParameters\",Array";
_serialport.RunMethod("setComPortParameters",new Object[]{(Object)(_baudrate),(Object)(_databits),(Object)(_stopbits),(Object)(_parity)});
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return "";
}
public int  _writebytes(byte[] _data) throws Exception{
long _l = 0L;
 //BA.debugLineNum = 71;BA.debugLine="public Sub writeBytes(data() As Byte) As Int";
 //BA.debugLineNum = 73;BA.debugLine="Dim l As Long = data.Length		'轉換成long長整數";
_l = (long) (_data.length);
 //BA.debugLineNum = 74;BA.debugLine="return SerialPort.RunMethod(\"writeBytes\",Array As";
if (true) return (int)(BA.ObjectToNumber(_serialport.RunMethod("writeBytes",new Object[]{(Object)(_data),(Object)(_l)})));
 //BA.debugLineNum = 75;BA.debugLine="End Sub";
return 0;
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}

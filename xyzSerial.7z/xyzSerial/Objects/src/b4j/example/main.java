package b4j.example;

import com.fazecast.jSerialComm.*;

import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();

public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            if (!false)
                System.setProperty("prism.lcdtext", "false");
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.setDensity(javafx.stage.Screen.getPrimary().getDpi());
            anywheresoftware.b4a.keywords.Common.LogDebug("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 600);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public static anywheresoftware.b4a.objects.B4XViewWrapper _button1 = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _button2 = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _button3 = null;
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
 //BA.debugLineNum = 17;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 18;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 19;BA.debugLine="MainForm.RootPane.LoadLayout(\"Layout1\")";
_mainform.getRootPane().LoadLayout(ba,"Layout1");
 //BA.debugLineNum = 20;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 21;BA.debugLine="End Sub";
return "";
}
public static String  _button1_click() throws Exception{
byte[] _data = null;
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
 //BA.debugLineNum = 28;BA.debugLine="Sub Button1_Click";
 //BA.debugLineNum = 31;BA.debugLine="Dim data() As Byte";
_data = new byte[(int) (0)];
;
 //BA.debugLineNum = 32;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 33;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 34;BA.debugLine="sb.Append( Chr(0X1b) & \"@\" ) '初始化打印機";
_sb.Append(BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr(((int)0x1b)))+"@");
 //BA.debugLineNum = 35;BA.debugLine="sb.Append( \"test測試 \" &CRLF )";
_sb.Append("test測試 "+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 36;BA.debugLine="sb.Append( \"test測試 \" &CRLF )";
_sb.Append("test測試 "+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 37;BA.debugLine="sb.Append( \"test測試 \" &CRLF )";
_sb.Append("test測試 "+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 38;BA.debugLine="sb.Append( \"test測試 \" &CRLF )";
_sb.Append("test測試 "+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 39;BA.debugLine="sb.Append( \"test測試 \" &CRLF )";
_sb.Append("test測試 "+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 40;BA.debugLine="sb.Append( Chr(0X1b) & \"d\" &  Chr(5)  )  '打印並進紙 n";
_sb.Append(BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr(((int)0x1b)))+"d"+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (5))));
 //BA.debugLineNum = 41;BA.debugLine="sb.Append( Chr(0X1d) & \"V\" & Chr(65) & Chr(0)  )";
_sb.Append(BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr(((int)0x1d)))+"V"+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (65)))+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (0))));
 //BA.debugLineNum = 42;BA.debugLine="data = sb.ToString.GetBytes(\"BIG5\")";
_data = _sb.ToString().getBytes("BIG5");
 //BA.debugLineNum = 44;BA.debugLine="inline.RunMethod(\"main03\", Array(data))";
_inline().RunMethod("main03",new Object[]{(Object)(_data)});
 //BA.debugLineNum = 47;BA.debugLine="End Sub";
return "";
}
public static String  _button2_click() throws Exception{
anywheresoftware.b4j.object.JavaObject _serialport = null;
Object[] _availableports = null;
anywheresoftware.b4j.object.JavaObject _port = null;
anywheresoftware.b4j.object.JavaObject _myserialport = null;
byte[] _data = null;
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
long _l = 0L;
int _bytestxed = 0;
 //BA.debugLineNum = 51;BA.debugLine="Private Sub Button2_Click";
 //BA.debugLineNum = 52;BA.debugLine="Dim SerialPort As JavaObject";
_serialport = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 55;BA.debugLine="SerialPort.InitializeStatic(\"com.fazecast.jSerial";
_serialport.InitializeStatic("com.fazecast.jSerialComm.SerialPort");
 //BA.debugLineNum = 58;BA.debugLine="Dim AvailablePorts() As Object = SerialPort.RunMe";
_availableports = (Object[])(_serialport.RunMethod("getCommPorts",(Object[])(anywheresoftware.b4a.keywords.Common.Null)));
 //BA.debugLineNum = 59;BA.debugLine="Log(\"串口清單--------------------\")";
anywheresoftware.b4a.keywords.Common.LogImpl("0327688","串口清單--------------------",0);
 //BA.debugLineNum = 60;BA.debugLine="For Each port As JavaObject In AvailablePorts";
_port = new anywheresoftware.b4j.object.JavaObject();
{
final Object[] group5 = _availableports;
final int groupLen5 = group5.length
;int index5 = 0;
;
for (; index5 < groupLen5;index5++){
_port = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(group5[index5]));
 //BA.debugLineNum = 62;BA.debugLine="Log(\"串口名稱:\"&port.RunMethod(\"getSystemPortName\",N";
anywheresoftware.b4a.keywords.Common.LogImpl("0327691","串口名稱:"+BA.ObjectToString(_port.RunMethod("getSystemPortName",(Object[])(anywheresoftware.b4a.keywords.Common.Null))),0);
 //BA.debugLineNum = 63;BA.debugLine="Log(\"串口類型:\"&port.RunMethod(\"getPortDescription\",";
anywheresoftware.b4a.keywords.Common.LogImpl("0327692","串口類型:"+BA.ObjectToString(_port.RunMethod("getPortDescription",(Object[])(anywheresoftware.b4a.keywords.Common.Null))),0);
 //BA.debugLineNum = 64;BA.debugLine="Log(\"串口完整資訊:\"&port.RunMethod(\"getDescriptivePort";
anywheresoftware.b4a.keywords.Common.LogImpl("0327693","串口完整資訊:"+BA.ObjectToString(_port.RunMethod("getDescriptivePortName",(Object[])(anywheresoftware.b4a.keywords.Common.Null))),0);
 //BA.debugLineNum = 65;BA.debugLine="Log(\"--------------------\")";
anywheresoftware.b4a.keywords.Common.LogImpl("0327694","--------------------",0);
 }
};
 //BA.debugLineNum = 69;BA.debugLine="Dim MySerialPort As JavaObject = AvailablePorts(1";
_myserialport = new anywheresoftware.b4j.object.JavaObject();
_myserialport = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(_availableports[(int) (1)]));
 //BA.debugLineNum = 72;BA.debugLine="MySerialPort.RunMethod(\"setComPortParameters\",Arr";
_myserialport.RunMethod("setComPortParameters",new Object[]{(Object)(19200),(Object)(8),(Object)(1),(Object)(0)});
 //BA.debugLineNum = 75;BA.debugLine="MySerialPort.RunMethod(\"openPort\",Null)";
_myserialport.RunMethod("openPort",(Object[])(anywheresoftware.b4a.keywords.Common.Null));
 //BA.debugLineNum = 78;BA.debugLine="Log(\"isOpen= \"&MySerialPort.RunMethod(\"isOpen\",Nu";
anywheresoftware.b4a.keywords.Common.LogImpl("0327707","isOpen= "+BA.ObjectToString(_myserialport.RunMethod("isOpen",(Object[])(anywheresoftware.b4a.keywords.Common.Null))),0);
 //BA.debugLineNum = 87;BA.debugLine="Log(\"Selected Port               = \"&MySerialPort";
anywheresoftware.b4a.keywords.Common.LogImpl("0327716","Selected Port               = "+BA.ObjectToString(_myserialport.RunMethod("getSystemPortName",(Object[])(anywheresoftware.b4a.keywords.Common.Null))),0);
 //BA.debugLineNum = 88;BA.debugLine="Log(\"Selected Baud rate          = \"&MySerialPort";
anywheresoftware.b4a.keywords.Common.LogImpl("0327717","Selected Baud rate          = "+BA.ObjectToString(_myserialport.RunMethod("getBaudRate",(Object[])(anywheresoftware.b4a.keywords.Common.Null))),0);
 //BA.debugLineNum = 89;BA.debugLine="Log(\"Selected Number of DataBits = \"&MySerialPort";
anywheresoftware.b4a.keywords.Common.LogImpl("0327718","Selected Number of DataBits = "+BA.ObjectToString(_myserialport.RunMethod("getNumDataBits",(Object[])(anywheresoftware.b4a.keywords.Common.Null))),0);
 //BA.debugLineNum = 90;BA.debugLine="Log(\"Selected Number of StopBits = \"&MySerialPort";
anywheresoftware.b4a.keywords.Common.LogImpl("0327719","Selected Number of StopBits = "+BA.ObjectToString(_myserialport.RunMethod("getNumStopBits",(Object[])(anywheresoftware.b4a.keywords.Common.Null))),0);
 //BA.debugLineNum = 91;BA.debugLine="Log(\"Selected Parity             = \"&MySerialPort";
anywheresoftware.b4a.keywords.Common.LogImpl("0327720","Selected Parity             = "+BA.ObjectToString(_myserialport.RunMethod("getParity",(Object[])(anywheresoftware.b4a.keywords.Common.Null))),0);
 //BA.debugLineNum = 95;BA.debugLine="Dim data() As Byte";
_data = new byte[(int) (0)];
;
 //BA.debugLineNum = 96;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 97;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 98;BA.debugLine="sb.Append( Chr(0X1b) & \"@\" ) '初始化打印機";
_sb.Append(BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr(((int)0x1b)))+"@");
 //BA.debugLineNum = 99;BA.debugLine="sb.Append( \"test測試 \" &CRLF )";
_sb.Append("test測試 "+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 100;BA.debugLine="sb.Append( \"test測試 \" &CRLF )";
_sb.Append("test測試 "+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 101;BA.debugLine="sb.Append( \"test測試 \" &CRLF )";
_sb.Append("test測試 "+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 102;BA.debugLine="sb.Append( \"test測試 \" &CRLF )";
_sb.Append("test測試 "+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 103;BA.debugLine="sb.Append( \"test測試 \" &CRLF )";
_sb.Append("test測試 "+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 104;BA.debugLine="sb.Append( Chr(0X1b) & \"d\" &  Chr(5)  )  '打印並進紙 n";
_sb.Append(BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr(((int)0x1b)))+"d"+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (5))));
 //BA.debugLineNum = 105;BA.debugLine="sb.Append( Chr(0X1d) & \"V\" & Chr(65) & Chr(0)  )";
_sb.Append(BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr(((int)0x1d)))+"V"+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (65)))+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (0))));
 //BA.debugLineNum = 107;BA.debugLine="data = sb.ToString.GetBytes(\"BIG5\")";
_data = _sb.ToString().getBytes("BIG5");
 //BA.debugLineNum = 109;BA.debugLine="Dim l As Long = data.Length		'轉換成long長整數";
_l = (long) (_data.length);
 //BA.debugLineNum = 112;BA.debugLine="Dim bytesTxed As Int = 0";
_bytestxed = (int) (0);
 //BA.debugLineNum = 113;BA.debugLine="bytesTxed = MySerialPort.RunMethod(\"writeBytes\",A";
_bytestxed = (int)(BA.ObjectToNumber(_myserialport.RunMethod("writeBytes",new Object[]{(Object)(_data),(Object)(_l)})));
 //BA.debugLineNum = 114;BA.debugLine="Log(\"bytesTxed= \"&bytesTxed)";
anywheresoftware.b4a.keywords.Common.LogImpl("0327743","bytesTxed= "+BA.NumberToString(_bytestxed),0);
 //BA.debugLineNum = 117;BA.debugLine="MySerialPort.RunMethod(\"closePort\",Null)";
_myserialport.RunMethod("closePort",(Object[])(anywheresoftware.b4a.keywords.Common.Null));
 //BA.debugLineNum = 119;BA.debugLine="End Sub";
return "";
}
public static String  _button3_click() throws Exception{
b4j.example.xyzserialport _serial = null;
Object[] _availableports = null;
anywheresoftware.b4j.object.JavaObject _port = null;
b4j.example.xyzserialport _myserialport = null;
byte[] _data = null;
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
 //BA.debugLineNum = 122;BA.debugLine="Private Sub Button3_Click";
 //BA.debugLineNum = 123;BA.debugLine="Dim serial As xyzSerialPort";
_serial = new b4j.example.xyzserialport();
 //BA.debugLineNum = 125;BA.debugLine="serial.Initialize";
_serial._initialize /*String*/ (ba);
 //BA.debugLineNum = 127;BA.debugLine="Dim AvailablePorts() As Object = serial.GetCommPo";
_availableports = (Object[])(_serial._getcommports /*Object*/ ());
 //BA.debugLineNum = 129;BA.debugLine="Log(\"串口清單--------------------\")";
anywheresoftware.b4a.keywords.Common.LogImpl("0524295","串口清單--------------------",0);
 //BA.debugLineNum = 130;BA.debugLine="For Each port As JavaObject In AvailablePorts";
_port = new anywheresoftware.b4j.object.JavaObject();
{
final Object[] group5 = _availableports;
final int groupLen5 = group5.length
;int index5 = 0;
;
for (; index5 < groupLen5;index5++){
_port = (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(group5[index5]));
 //BA.debugLineNum = 132;BA.debugLine="Log(\"串口名稱:\"&port.RunMethod(\"getSystemPortName\",N";
anywheresoftware.b4a.keywords.Common.LogImpl("0524298","串口名稱:"+BA.ObjectToString(_port.RunMethod("getSystemPortName",(Object[])(anywheresoftware.b4a.keywords.Common.Null))),0);
 //BA.debugLineNum = 133;BA.debugLine="Log(\"串口類型:\"&port.RunMethod(\"getPortDescription\",";
anywheresoftware.b4a.keywords.Common.LogImpl("0524299","串口類型:"+BA.ObjectToString(_port.RunMethod("getPortDescription",(Object[])(anywheresoftware.b4a.keywords.Common.Null))),0);
 //BA.debugLineNum = 134;BA.debugLine="Log(\"串口完整資訊:\"&port.RunMethod(\"getDescriptivePort";
anywheresoftware.b4a.keywords.Common.LogImpl("0524300","串口完整資訊:"+BA.ObjectToString(_port.RunMethod("getDescriptivePortName",(Object[])(anywheresoftware.b4a.keywords.Common.Null))),0);
 //BA.debugLineNum = 135;BA.debugLine="Log(\"--------------------\")";
anywheresoftware.b4a.keywords.Common.LogImpl("0524301","--------------------",0);
 }
};
 //BA.debugLineNum = 138;BA.debugLine="Dim MySerialPort As xyzSerialPort";
_myserialport = new b4j.example.xyzserialport();
 //BA.debugLineNum = 140;BA.debugLine="MySerialPort.Initialize";
_myserialport._initialize /*String*/ (ba);
 //BA.debugLineNum = 141;BA.debugLine="MySerialPort.SetComPort(\"COM13\")";
_myserialport._setcomport /*String*/ ("COM13");
 //BA.debugLineNum = 142;BA.debugLine="MySerialPort.setComPortParameters(19200,8,1,0)";
_myserialport._setcomportparameters /*String*/ ((int) (19200),(int) (8),(int) (1),(int) (0));
 //BA.debugLineNum = 144;BA.debugLine="MySerialPort.openPort";
_myserialport._openport /*boolean*/ ();
 //BA.debugLineNum = 147;BA.debugLine="Dim data() As Byte";
_data = new byte[(int) (0)];
;
 //BA.debugLineNum = 148;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 149;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 150;BA.debugLine="sb.Append( Chr(0X1b) & \"@\" ) '初始化打印機";
_sb.Append(BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr(((int)0x1b)))+"@");
 //BA.debugLineNum = 151;BA.debugLine="sb.Append( \"test測試 \" &CRLF )";
_sb.Append("test測試 "+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 152;BA.debugLine="sb.Append( \"test測試 \" &CRLF )";
_sb.Append("test測試 "+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 153;BA.debugLine="sb.Append( \"test測試 \" &CRLF )";
_sb.Append("test測試 "+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 154;BA.debugLine="sb.Append( \"test測試 \" &CRLF )";
_sb.Append("test測試 "+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 155;BA.debugLine="sb.Append( \"test測試 \" &CRLF )";
_sb.Append("test測試 "+anywheresoftware.b4a.keywords.Common.CRLF);
 //BA.debugLineNum = 156;BA.debugLine="sb.Append( Chr(0X1b) & \"d\" &  Chr(5)  )  '打印並進紙 n";
_sb.Append(BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr(((int)0x1b)))+"d"+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (5))));
 //BA.debugLineNum = 157;BA.debugLine="sb.Append( Chr(0X1d) & \"V\" & Chr(65) & Chr(0)  )";
_sb.Append(BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr(((int)0x1d)))+"V"+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (65)))+BA.ObjectToString(anywheresoftware.b4a.keywords.Common.Chr((int) (0))));
 //BA.debugLineNum = 159;BA.debugLine="data = sb.ToString.GetBytes(\"BIG5\")";
_data = _sb.ToString().getBytes("BIG5");
 //BA.debugLineNum = 161;BA.debugLine="MySerialPort.writeBytes(data)";
_myserialport._writebytes /*int*/ (_data);
 //BA.debugLineNum = 163;BA.debugLine="MySerialPort.closePort";
_myserialport._closeport /*boolean*/ ();
 //BA.debugLineNum = 164;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4j.object.JavaObject  _inline() throws Exception{
 //BA.debugLineNum = 25;BA.debugLine="Sub inline As JavaObject";
 //BA.debugLineNum = 26;BA.debugLine="Return Me";
if (true) return (anywheresoftware.b4j.object.JavaObject) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4j.object.JavaObject(), (java.lang.Object)(main.getObject()));
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return null;
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 10;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 11;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 12;BA.debugLine="Private Button1 As B4XView";
_button1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Private Button2 As Button";
_button2 = new anywheresoftware.b4j.objects.ButtonWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Private Button3 As Button";
_button3 = new anywheresoftware.b4j.objects.ButtonWrapper();
 //BA.debugLineNum = 15;BA.debugLine="End Sub";
return "";
}

public static void main01 () {
	System.out.println("Hello World"); // 输出 Hello World

	SerialPort[] serialPorts = SerialPort.getCommPorts();//查找所有串口

	for(SerialPort port:serialPorts){
	    System.out.println("Port:"+port.getSystemPortName());//打印串口名称，如COM4
	    System.out.println("PortDesc:"+port.getPortDescription());//打印串口类型，如USB Serial
	    System.out.println("PortDesc:"+port.getDescriptivePortName());//打印串口的完整类型，如USB-SERIAL CH340(COM4)
	}
		
		
}

public static void main02 (){
 
   
   }//end of main02()


	public static void main03 (byte[] bytes)
	{

		int BaudRate = 19200;
		int DataBits = 8;
		int StopBits = SerialPort.ONE_STOP_BIT;
		int Parity   = SerialPort.NO_PARITY;

		System.out.println("StopBits= "+SerialPort.ONE_STOP_BIT);
		System.out.println("Parity= "+SerialPort.NO_PARITY);

		SerialPort [] AvailablePorts = SerialPort.getCommPorts();
		
		System.out.println("\n\n SerialPort Data Transmission");

		// use the for loop to print the available serial ports
		System.out.print("\n\n Available Ports ");
		for (int i = 0; i<AvailablePorts.length ; i++)
		{
			System.out.println(i + " - " + AvailablePorts[i].getSystemPortName() + " -> " + AvailablePorts[i].getDescriptivePortName());
		}
		
		System.out.println("=======================");	
		 
        //Open the first Available port
        SerialPort MySerialPort = AvailablePorts[1];
        

        // Set Serial port Parameters
        MySerialPort.setComPortParameters(BaudRate,DataBits,StopBits,Parity);//Sets all serial port parameters at one time

               
        MySerialPort.openPort(); //open the port
        //Arduino Will Reset 
        //System.out.println(" Watch Arduino for Reset ");
        //Thread.sleep(5000);//Delay added to so you can see the Arduino getting Resetted


        if (MySerialPort.isOpen())
    		System.out.println("\n" + MySerialPort.getSystemPortName() + "  is Open ");
        else
   			System.out.println(" Port not open ");
      
      	

      	//Display the Serial Port parameters
      	System.out.println("\n Selected Port               = " + MySerialPort.getSystemPortName());
      	System.out.println(" Selected Baud rate          = " + MySerialPort.getBaudRate());
        System.out.println(" Selected Number of DataBits = " + MySerialPort.getNumDataBits());
      	System.out.println(" Selected Number of StopBits = " + MySerialPort.getNumStopBits());
      	System.out.println(" Selected Parity             = " + MySerialPort.getParity());
      	
      	//Thread.sleep(2000); //Delay introduced because when the SerialPort is opened ,Arduino gets resetted
      						// Time for the code in Arduino to rerun after Reset

      	try 
      	{
	
				
		int bytesTxed  = 0;		
		//byte[] bytes = s1.getBytes(); 
    	bytesTxed  = MySerialPort.writeBytes(bytes,bytes.length); 				
				
				

      			System.out.print(" Bytes Transmitted -> " + bytesTxed );
      			   			
		} 
		catch (Exception e) 
		{
			 e.printStackTrace(); 
		}


      	MySerialPort.closePort(); //Close the port

      	if (MySerialPort.isOpen())
    		System.out.println(MySerialPort.getSystemPortName() + " is Open ");
        else
   			System.out.println("\n Port not open ");
   
	}//end of main() 
}
